# AXIOM Launcher

A minimal Android launcher for Standoff 2. The app contains one centered **BAŞLAT** button and opens the installed game through Android's package manager.

## Requirements

- Android Studio (recent stable version)
- JDK 17
- Android SDK 35

## Build

1. Open this repository in Android Studio.
2. Allow Gradle sync to finish.
3. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Install the generated APK from `app/build/outputs/apk/debug/`.

You can also build from a terminal with:

```bash
./gradlew assembleDebug
```

A Gradle wrapper is not included in this source archive; Android Studio can use its configured Gradle installation, or you can generate a wrapper with `gradle wrapper`.

## Game package

The launcher targets the package ID `com.axlebolt.standoff2`. If the installed game build uses a different package ID in your region/store, update `GAME_PACKAGE` in `MainActivity.kt` and the matching `<queries>` entry in `AndroidManifest.xml`.

## Privacy

The app does not request network, storage, accessibility, overlay, or root permissions. It only checks for and launches the configured game package.
