package com.axiom.launcher

import android.content.ActivityNotFoundException
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val GAME_PACKAGE = "com.axlebolt.standoff2"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = android.graphics.Color.rgb(8, 11, 18)
        window.navigationBarColor = android.graphics.Color.rgb(5, 7, 11)

        setContent {
            MaterialTheme {
                AxiomLauncher(onStart = ::launchStandoff)
            }
        }
    }

    private fun launchStandoff() {
        try {
            val launchIntent = packageManager
                .getLaunchIntentForPackage(GAME_PACKAGE)

            if (launchIntent == null) {
                Toast.makeText(
                    this,
                    "Standoff 2 bulunamadı. Oyunun kurulu olduğunu kontrol et.",
                    Toast.LENGTH_LONG
                ).show()
                return
            }

            startActivity(launchIntent)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "Oyun başlatılamadı.", Toast.LENGTH_SHORT).show()
        } catch (_: SecurityException) {
            Toast.makeText(this, "Oyunu açmak için izin alınamadı.", Toast.LENGTH_SHORT).show()
        }
    }
}

@Composable
private fun AxiomLauncher(onStart: () -> Unit) {
    val background = Brush.verticalGradient(
        colors = listOf(
            Color(0xFF080B12),
            Color(0xFF101B2B),
            Color(0xFF05070B)
        )
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(background)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(28.dp)
        ) {
            Text(
                text = "AXIOM",
                color = Color(0xFFF2F6FC),
                fontSize = 34.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 8.sp
            )

            Text(
                text = "STANDOFF 2 LAUNCHER",
                color = Color(0xFF8FA6C4),
                fontSize = 11.sp,
                letterSpacing = 3.sp,
                textAlign = TextAlign.Center
            )

            Button(
                onClick = onStart,
                modifier = Modifier.size(184.dp),
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF147DCC),
                    contentColor = Color.White
                ),
                elevation = ButtonDefaults.buttonElevation(
                    defaultElevation = 12.dp,
                    pressedElevation = 3.dp
                )
            ) {
                Text(
                    text = "BAŞLAT",
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
            }
        }
    }
}
